# Fantanglo

Fan and temperature control for Intel iMacs running Debian (12 or 13).

Fantanglo reads the GPU, CPU and Apple SMC temperature sensors and drives the
iMac's fans through the Linux `applesmc` driver. It was written for an
iMac12,2 whose replacement GPU (a Quadro K3100M) is invisible to Apple's own
fan control: the SMC reports its GPU diode as −127 °C, so the stock behavior
ignores GPU heat entirely.

## What it does

- **Profiles:** each fan runs on Apple automatic control, at a fixed speed, or
  on a curve driven by any sensor. Ready-made profiles: Auto, Balanced,
  Render and Full blast.
- **Rules with hysteresis:** for example "GPU at 80 °C → every fan at full
  speed, until the GPU has cooled to 65 °C". Rules only ever raise speeds.
- **Schedule:** time windows that switch profile, such as quiet at night.
- **Full blast:** maximum speed for 15 minutes, 30 minutes or an hour, from the
  window or the tray.
- **Disk temperatures:** SATA drives report their own temperature through the
  kernel's `drivetemp` module. A fan curve can follow a disk, which helps
  when the drive bay sensor is missing (its HDD fan otherwise runs at full
  speed).
- **Tray icon:** live temperatures and fan speeds, profile switching and full
  blast, with no window open.

Speeds are expressed as a percentage of each fan's own range. iMac fans never
stop completely: the hardware enforces a minimum, around 940–1150 rpm on the
iMac12,2.

## Safety

- GPU or CPU at the critical temperature (90 °C by default) sends every fan to
  maximum, whatever else is configured.
- If the GPU or CPU temperature cannot be read, every fan goes to maximum.
- When the service stops, crashes or hangs (systemd watchdog), the fans are
  handed back to Apple's automatic control.

## Install

```sh
sudo apt install ./fantanglo_0.1.2_amd64.deb
```

This installs and starts the `fantangld` service. Open **Fantanglo** from the
application menu. Under **Settings**, *Start at login* puts it in the tray
whenever you log in. Members of the `sudo` group can change settings; any
user can watch them.

Remove it with `sudo apt remove fantanglo`; the fans return to automatic
control. `sudo apt purge fantanglo` also deletes `/etc/fantanglo`.

## Layout

| Part | What it is |
| --- | --- |
| `fantangld` | Root service: reads sensors, applies profiles, rules and safety limits, and serves `/run/fantanglo/fantangld.sock` |
| `fantanglo` | GTK4/libadwaita app and tray icon; talks to the service |
| `/etc/fantanglo/config.toml` | Settings, written by the service when you save in the app |

`journalctl -u fantangld` shows what the service did and why.

## Development

```sh
cargo test --workspace
cargo build --release --workspace && scripts/package-deb.py   # → dist/
```

To try it without root or without touching the fans, run the service in
observation mode with a private socket and point the app at it:

```sh
target/debug/fantangld --dry-run --config /tmp/f.toml --socket /tmp/f.sock
FANTANGLO_SOCKET=/tmp/f.sock target/debug/fantanglo
```

To publish a release: bump the version in `Cargo.toml`, build, run
`scripts/package-deb.py`, then `scripts/publish-website.py --title ... --highlight ...`
and commit and push the website. Installed apps see it within an hour.

`scripts/make-icons.py` regenerates the icons from
`data/icons/fantanglo-source.png`.
